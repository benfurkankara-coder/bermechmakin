import React, { useState } from "react";

const App = () => {
  // ... (user code buraya gelecek, tam hali ekleniyor)
};

export default App;
